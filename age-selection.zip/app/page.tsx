import AgeSelection from "@/components/age-selection"

export default function Home() {
  return (
    <main className="min-h-screen bg-gray-50">
      <AgeSelection />
    </main>
  )
}
